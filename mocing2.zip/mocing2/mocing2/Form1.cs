﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mocing2
{
    public partial class Form1 : Form
    {
        int _x; // x-coordinat for grøn bold
        int _y; // y-coordinat for grøn bold
        int elX; // X-coordinat for rød bold
        int elY; // y-coordinat for rød bold

        bool plusX; //bool fortæller hvornår rød bold skal skifte retning.
        bool plusY;

        int wi; //width på spillepladen "panel1"
        int hei; // højden på spillepladen

        int counter; //Til tidtælleren, som er en slags pointtavle.

        enum Position
        {
            Left, Right, Down, Up //konstanter der fortæller, hvilken KEY spilleren har trykket på sidst.
        }
        private Position objPosition; //grøn bold retning

        public Form1()
        {
            InitializeComponent();

            /* programmet starter og der smides værdier i variablerne.
               Grøn bold starter øverst til venstre og går nedad. Rødbold starter i midten */
            _x = 1;
            _y = 1;
           
            plusX = true;
            plusY = true;

            wi = panel1.Width-40;
            hei = panel1.Height-40;
            counter = 0;

            objPosition = Position.Down; // Ikke noget synderlig grund til at nedad starter. Det kan man gøre som man vild.

            elX = wi/2;
            elY = hei/2;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
         
            //denne her gør intet. det var en fejl den kom med.
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            /*
             * Hele game-engine er her i timeren. Timeren er et objekt, der gør noget i et indstillet tidsinterval.
             * Jeg har sat timeren til at foretage følgende beregninger for objekternes position hver milisekund.
             * 
             * Det handler sådan set bare om at ++ eller -- på objekternes koordinater.
             * 
             */

            // her starter udregningen for den røde computerstyrede bold
            if (elX > wi)  //Hvis objektets x-værdi er større en bredden på spillepladen, så sætter vi bold til at ændre retning.
                plusX = false;
            else if(elX < 0)
                plusX = true;
            if (elY < 0) //Det samme sker ved Y-værdierne
                plusY = true;
            else if (elY >= hei)
                plusY = false;


            if (plusX)
            {
                elX += 12; //Hvert "skridt" bolden tager er 2 pixels. Hvis man øge sværhedsgrad kan man øge disse næste fire tal.
            }
            else
            {
                elX -= 22;
            }

            if (plusY)
            {
                elY += 12;
            }
            else
            {
                elY -= 22; 
            }


            /* Dernæst spilleres grønne bold.
             * Den lægger til positionen, på den knap, 
             * der sidst er trykket.
             */

            if (objPosition == Position.Left)
            {
                
                    _x -= 12;
                if(_x < 0 ) //Hvis man rammer kanten af spillepladen, dukker man op i modsatte ende. Spilledepladen er altså uendelig.
                {
                    _x = wi;
                }
                

            }
            else if(objPosition == Position.Right)
            {
                
                    _x += 12;
                if (_x > wi)
                {
                    _x = 0;
                }

            }
            if (objPosition == Position.Down)
            {
                
                    _y += 12;
                if (_y > hei)
                {
                    _y = 0;
                }
            }
            else if (objPosition == Position.Up)
            {
                
                    _y -= 12;
                if (_y < 0)
                {
                    _y = hei;
                }
            }


            /* Denne udregning afgør om man har tabt spillet.
             * Hvis afstanden til objekter er mindre, end deres radiusser. Så må du røre hinanden.
             * 
             * Spillepladen er sådan bygget op fra computerens side, at koordinat 0,0 er i øverst venstre hjørne.
             * Y aksen er positiv NEDAD og X aksen er positiv mod højre.
             * Det betyder, at hvis vi skal regne rigtigt, så vil vi KUN have positive værdier
             * Derfor bruger vi her Math.Abs(), som er en matematisk funktion, der kun returnerer positive værdier.
             * Eksempelvis: Math.Abs(-5) --> 5 
             */
            if (Math.Abs(_x - elX) < 38 && Math.Abs(_y - elY) <38)
                timer1.Enabled = false; //vi slukker timeren og dermed spillet, hvis objekterne rører hinanden.
            counter++;
            label1.Text = Convert.ToString(counter); 

            panel1.Invalidate(); //Dette stykke kode opdaterer panel1, som kan gentegne objekter i nye positions.
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            /* Hvis man skal tegne noget, så skal det være i elementernes "Paint-event".
             * Tryk på fx på et panel ude i designeren. I menuen trykker i på lynet.
             * Så dobbeltklikker i på Paint-eventet. Og så kommer I herud i koden:
             */

            e.Graphics.FillEllipse(Brushes.Green, _x, _y, 40, 40); // selve objekterne, der bliver tegnet.
            e.Graphics.FillEllipse(Brushes.Red,elX,elY,40,40);
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
           if(e.KeyChar == (char)Keys.Return)
            {
                /* Hvis man trykker ENTER
                 * så genstarter man spillet.
                 * Alle værder nulstilles, og uret starter igen.
                 */

                _x = 1;
                _y = 1;

                plusX = true;
                plusY = true;

                wi = panel1.Width - 40;
                hei = panel1.Height - 40;
                counter = 0;

                objPosition = Position.Down; // Ikke noget synderlig grund til at nedad starter. Det kan man gøre som man vild.

                elX = wi / 2;
                elY = hei / 2;
                label1.Text = "0";
                timer1.Enabled = true;

            }

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                objPosition = Position.Left;
            }
            else if (e.KeyCode == Keys.Right)
            {
                objPosition = Position.Right;
            }
            else if (e.KeyCode == Keys.Up)
            {
                objPosition = Position.Up;
            }
            else if (e.KeyCode == Keys.Down)
            {
                objPosition = Position.Down;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //bruger ikke denne
        }
    }
}
